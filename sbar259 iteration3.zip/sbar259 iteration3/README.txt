item5.sql was from iteration 2 where it creates the tables
item7.sql was from iteration 2 where you insert items into the tables

